# SpaceWars

Goal of the Space Wars game is to get a high score by shooting as many alien ships as possible. The faster ships on the higher levels give more points.

Space Wars is the first game written from scratch in Python and Pygame by Dan Petersson.
It has no relation to original "Space Wars" game from 1977. 

Written and tested on:
Windows 10,
Python  3.8,
Pygame  1.9.6
