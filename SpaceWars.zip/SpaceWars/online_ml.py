import sklearn
from sklearn.preprocessing import StandardScaler
import numpy as np
from high_scores import high_scores
from river import cluster
from river import naive_bayes
import pickle
import pymongo

# Cluster Label
LABELS = {0: 'Beginner', 1: 'collector', 2: 'Killer'}

# def scale_data(data):
#     scaler = StandardScaler()
#     X_scale = scaler.fit_transform(np.array(data).reshape(-1, 1))
#     X_scale = {i: value[0] for i, value in enumerate(X_scale)}
#     return(X_scale)


def write_k_means_model(model):
    # Save the clustering model
    # print('model=',model)
    with open('KMeans1.pkl', 'wb') as f:
        pickle.dump(model, f)


def write_clas_model(model):
    # Save the clustering model
    # print('model=',model)
    with open('Hoeffding1.pkl', 'wb') as f:
        pickle.dump(model, f)


def load_model(path_to_filename):
    # Load the clustering model
    with open(path_to_filename, 'rb') as f:
        model = pickle.load(f)
    return model

# def train_model(data,streamkmeans,classifier): # expecting data = list of dict
#    data = scale_data(data)
#    data = [dict(data)]
#    #print('data=',data)
#    # Continue training the clustering model
#    for x in data:
#        streamkmeans = streamkmeans.learn_one(x)
#    # Continue training the classification model
#    for x in data:
#        cluster_id = streamkmeans.predict_one(x)
#        label = LABELS[cluster_id]
#        classifier = classifier.learn_one(x, label)
#    return streamkmeans, classifier


def train_model(kmeans, Hoeffding1_model, timestamp):
    #data_all = high_scores.check_data_after_timestamp(timestamp)
    client = pymongo.MongoClient(
        "mongodb+srv://Rindfleisch:1QV3chAI797qqdZE@cluster0.xziinwk.mongodb.net/")
    db = client.Real_time

    collection = db.Space_wars
    data = list(collection.find())


    if data == []:
        pass
    else:
        for da in data:
            keys_to_extract = ['A2', 'A3', 'A6', 'A7', 'A8', 'A9', 'A10']
            extracted_data = {key: float(
                da[key]) if key in da else 0.0 for key in keys_to_extract}
            print(extracted_data)

            kmeans = kmeans.learn_one(extracted_data)
            #print(kmeans)

            # kmeans = kmeans.learn_one(extracted_data)
            # Continue training the classification model
            cluster_id = kmeans.predict_one(extracted_data)
            #print('cluster ',cluster_id)
            label = LABELS[cluster_id]
    
            # print(label)
            # print(len(label))

            Hoeffding1_model = Hoeffding1_model.learn_one(
                extracted_data, label)

    return kmeans, Hoeffding1_model



def predict_gamer(new_data, Hoeffding1_model):  # expecting new data = dict
    #data = scale_data(new_data)
    data = new_data
    try:
        # print('data',data)
        prediction = Hoeffding1_model.predict_one(data)
        #print(prediction)
        # rint("check1")
    except:
        # print("check2")
        prediction = "Beginner"
    return prediction
